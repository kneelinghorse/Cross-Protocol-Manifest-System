#!/usr/bin/env node

// src/proto.js
import fs from "fs";
import path from "path";

// src/data_protocol_v_1_1_1.js
function jsonCanon(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map((v) => jsonCanon(v)).join(",") + "]";
  const keys = Object.keys(value).sort();
  return "{" + keys.map((k) => JSON.stringify(k) + ":" + jsonCanon(value[k])).join(",") + "}";
}
function dget(obj, path2) {
  if (!path2) return obj;
  const p = path2.replace(/\[(\d+)\]/g, ".$1").split(".");
  let cur = obj;
  for (const k of p) {
    if (cur == null) return void 0;
    cur = cur[k];
  }
  return cur;
}
function dset(obj, path2, val) {
  const parts = path2.split(".");
  let cur = obj;
  while (parts.length > 1) {
    const k = parts.shift();
    if (!(k in cur) || typeof cur[k] !== "object") cur[k] = {};
    cur = cur[k];
  }
  cur[parts[0]] = val;
}
function clone(x) {
  const seen = /* @__PURE__ */ new WeakSet();
  return JSON.parse(JSON.stringify(x, (key, value) => {
    if (typeof value === "object" && value !== null) {
      if (seen.has(value)) {
        return "[Circular]";
      }
      seen.add(value);
    }
    return value;
  }));
}
function hash(value) {
  if (value === null || typeof value !== "object") {
    const str2 = String(value);
    let h2 = 2166136261;
    const p2 = 16777619;
    const len = str2.length;
    let i = 0;
    for (; i + 8 <= len; i += 8) {
      h2 ^= str2.charCodeAt(i);
      h2 = h2 * p2 >>> 0;
      h2 ^= str2.charCodeAt(i + 1);
      h2 = h2 * p2 >>> 0;
      h2 ^= str2.charCodeAt(i + 2);
      h2 = h2 * p2 >>> 0;
      h2 ^= str2.charCodeAt(i + 3);
      h2 = h2 * p2 >>> 0;
      h2 ^= str2.charCodeAt(i + 4);
      h2 = h2 * p2 >>> 0;
      h2 ^= str2.charCodeAt(i + 5);
      h2 = h2 * p2 >>> 0;
      h2 ^= str2.charCodeAt(i + 6);
      h2 = h2 * p2 >>> 0;
      h2 ^= str2.charCodeAt(i + 7);
      h2 = h2 * p2 >>> 0;
    }
    for (; i < len; i++) {
      h2 ^= str2.charCodeAt(i);
      h2 = h2 * p2 >>> 0;
    }
    return "fnv1a64-" + h2.toString(16).padStart(16, "0");
  }
  if (Array.isArray(value)) {
    let h2 = 2166136261;
    const p2 = 16777619;
    h2 ^= 91;
    h2 = h2 * p2 >>> 0;
    for (let i = 0; i < value.length; i++) {
      const itemHash = hash(value[i]);
      for (let j = 0; j < Math.min(8, itemHash.length); j++) {
        h2 ^= itemHash.charCodeAt(j);
        h2 = h2 * p2 >>> 0;
      }
      if (i < value.length - 1) {
        h2 ^= 44;
        h2 = h2 * p2 >>> 0;
      }
    }
    h2 ^= 93;
    h2 = h2 * p2 >>> 0;
    return "fnv1a64-" + h2.toString(16).padStart(16, "0");
  }
  const str = jsonCanon(value);
  let h = 2166136261;
  const p = 16777619;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = h * p >>> 0;
  }
  return "fnv1a64-" + h.toString(16).padStart(16, "0");
}
var Validators = /* @__PURE__ */ new Map();
function registerValidator(name, fn) {
  Validators.set(name, fn);
}
function runValidators(manifest, selected = []) {
  const names = selected.length ? selected : Array.from(Validators.keys());
  const results = [];
  for (const n of names) {
    const r = Validators.get(n)?.(manifest) || { ok: true };
    results.push({ name: n, ...r });
  }
  const ok = results.every((r) => r.ok);
  return { ok, results };
}
registerValidator("core.shape", (m) => {
  const issues = [];
  if (!m?.dataset?.name) issues.push({ path: "dataset.name", msg: "dataset.name is required", level: "error" });
  if (!m?.schema?.fields || typeof m.schema.fields !== "object" || !Object.keys(m.schema.fields).length) {
    issues.push({ path: "schema.fields", msg: "at least one field required", level: "error" });
  }
  const lc = m?.dataset?.lifecycle;
  if (lc && !["active", "deprecated"].includes(lc.status)) {
    issues.push({ path: "dataset.lifecycle.status", msg: "status must be active|deprecated", level: "error" });
  }
  return { ok: issues.length === 0, issues };
});
registerValidator("schema.keys", (m) => {
  const issues = [];
  const pk = m?.schema?.primary_key;
  if (pk) {
    const fields = m.schema.fields || {};
    const pkArr = Array.isArray(pk) ? pk : [pk];
    for (const f of pkArr) if (!(f in fields)) issues.push({ path: "schema.primary_key", msg: `primary key field missing: ${f}`, level: "error" });
  }
  return { ok: issues.length === 0, issues };
});
registerValidator("governance.pii_policy", (m) => {
  const issues = [];
  const anyPII = Object.values(m?.schema?.fields || {}).some((f) => f.pii === true);
  if (anyPII) {
    const cls = m?.governance?.policy?.classification;
    if (cls !== "pii") {
      issues.push({ path: "governance.policy.classification", msg: 'PII fields present \u2192 classification should be "pii"', level: "warn" });
    }
    if (m?.governance?.storage_residency && m?.governance?.storage_residency?.encrypted_at_rest !== true) {
      issues.push({ path: "governance.storage_residency.encrypted_at_rest", msg: "PII datasets should be encrypted at rest", level: "warn" });
    }
  }
  return { ok: issues.length === 0, issues };
});
registerValidator("operations.refresh", (m) => {
  const r = m?.operations?.refresh;
  if (!r) return { ok: true };
  const issues = [];
  if (r.schedule && !["hourly", "daily", "cron"].includes(r.schedule)) issues.push({ path: "operations.refresh.schedule", msg: "schedule must be hourly|daily|cron", level: "error" });
  return { ok: issues.length === 0, issues };
});
function query(manifest, expr) {
  const [rawPath, op, ...rest] = String(expr).split(":");
  const rhs = rest.join(":");
  if (!rawPath || !op) return false;
  if (rawPath.startsWith("lineage.") && op === "contains") {
    const arr = dget(manifest, rawPath);
    return Array.isArray(arr) && arr.some((x) => (x?.id || "").includes(rhs));
  }
  if (rawPath === "schema.fields" && op === "contains") {
    const fields = manifest.schema?.fields || {};
    return Object.keys(fields).some((k) => k.includes(rhs));
  }
  const lhs = dget(manifest, rawPath);
  switch (op) {
    case ":=:":
    case "=":
      return String(lhs) === rhs;
    case "contains":
      return String(lhs ?? "").includes(rhs);
    case ">":
      return Number(lhs) > Number(rhs);
    case "<":
      return Number(lhs) < Number(rhs);
    case ">=":
      return Number(lhs) >= Number(rhs);
    case "<=":
      return Number(lhs) <= Number(rhs);
    default:
      return false;
  }
}
function normalize(manifest) {
  const m = clone(manifest || {});
  if (!m.schema) m.schema = {};
  if (!m.schema.fields) m.schema.fields = {};
  m.schema_hash = hash(m.schema);
  m.field_hashes = {};
  for (const [k, v] of Object.entries(m.schema.fields)) m.field_hashes[k] = hash(v);
  return m;
}
function diff(a, b) {
  const A = normalize(a);
  const B = normalize(b);
  const changes = [];
  function walk(pa, va, vb) {
    if (va === vb) return;
    if (typeof va !== typeof vb) {
      changes.push({ path: pa, from: va, to: vb });
      return;
    }
    const isObj = (v) => v && typeof v === "object" && !Array.isArray(v);
    if (!isObj(va) || !isObj(vb)) {
      if (JSON.stringify(va) !== JSON.stringify(vb)) {
        changes.push({ path: pa, from: va, to: vb });
      }
      return;
    }
    const keys = /* @__PURE__ */ new Set([...Object.keys(va || {}), ...Object.keys(vb || {})]);
    for (const k of keys) {
      const hasInA = k in (va || {});
      const hasInB = k in (vb || {});
      if (!hasInA && hasInB) {
        changes.push({ path: pa ? pa + "." + k : k, from: void 0, to: vb[k] });
      } else if (hasInA && !hasInB) {
        changes.push({ path: pa ? pa + "." + k : k, from: va[k], to: void 0 });
      } else {
        walk(pa ? pa + "." + k : k, va[k], vb[k]);
      }
    }
  }
  walk("", A, B);
  const breaking = [];
  for (const c of changes) {
    if (c.path === "schema.primary_key") breaking.push({ ...c, reason: "primary key changed" });
    if (c.path.startsWith("schema.fields.") && c.path.endsWith(".type")) breaking.push({ ...c, reason: "column type changed" });
    if (c.path.startsWith("schema.fields.") && c.to === void 0 && c.from !== void 0) {
      const parts = c.path.split(".");
      if (parts.length === 3 && !c.path.includes(".type") && !c.path.includes(".required") && !c.path.includes(".pii") && !c.path.includes(".description")) {
        breaking.push({ ...c, reason: "column dropped" });
      }
    }
    if (c.path.startsWith("schema.fields.") && c.path.endsWith(".required") && c.to === true) breaking.push({ ...c, reason: "required flag changed" });
    if (c.path.startsWith("schema.fields.") && c.path.endsWith(".pii")) breaking.push({ ...c, reason: "pii flag changed" });
    if (c.path === "dataset.lifecycle.status" && dget(a, "dataset.lifecycle.status") === "active" && dget(b, "dataset.lifecycle.status") === "deprecated") {
      breaking.push({ ...c, reason: "lifecycle downgrade" });
    }
    if (c.path === "schema_hash") breaking.push({ ...c, reason: "schema changed" });
    if (c.path.startsWith("schema.fields.") && c.from === void 0 && c.to && c.to.required === true) {
      breaking.push({ ...c, reason: "required flag changed", path: c.path + ".required" });
    }
  }
  const significant = changes.filter((c) => c.path.startsWith("governance.") || c.path.startsWith("lineage.") || c.path.startsWith("operations.refresh"));
  return { changes, breaking, significant };
}
function generateMigration(fromManifest, toManifest) {
  const d = diff(fromManifest, toManifest);
  const steps = [];
  for (const change of d.changes) {
    const p = change.path;
    if (p.startsWith("schema.fields.") && change.from === void 0 && change.to !== void 0) {
      const parts = p.split(".");
      if (parts.length === 3) {
        const fieldName = parts[2];
        const fieldDef = dget(toManifest, `schema.fields.${fieldName}`) || {};
        steps.push(`ADD COLUMN ${fieldName} ${fieldDef.type || "unknown"}`);
        if (fieldDef.required) {
          steps.push(`-- BACKFILL: make '${fieldName}' NOT NULL (add default or backfill)`);
        }
        if (fieldDef.pii) {
          steps.push(`-- POLICY: '${fieldName}' now PII; ensure masking/encryption policy`);
        }
      }
    }
    if (p.startsWith("schema.fields.") && change.to === void 0 && change.from !== void 0) {
      const parts = p.split(".");
      if (parts.length === 3 && !p.includes(".type") && !p.includes(".required") && !p.includes(".pii") && !p.includes(".description")) {
        const fieldName = parts[2];
        steps.push(`DROP COLUMN ${fieldName}`);
      }
    }
    if (p.startsWith("schema.fields.") && p.endsWith(".type")) {
      const fieldName = p.split(".")[2];
      steps.push(`ALTER COLUMN ${fieldName} TYPE ${change.to} /* from ${change.from} */`);
    }
    if (p.startsWith("schema.fields.") && p.endsWith(".required") && change.to === true) {
      const fieldName = p.split(".")[2];
      steps.push(`-- BACKFILL: make '${fieldName}' NOT NULL (add default or backfill)`);
    }
    if (p.startsWith("schema.fields.") && p.endsWith(".pii") && change.to === true) {
      const fieldName = p.split(".")[2];
      steps.push(`-- POLICY: '${fieldName}' now PII; ensure masking/encryption policy`);
    }
    if (p === "schema.primary_key") {
      steps.push(`-- PRIMARY KEY changed (rebuild index / validate uniqueness)`);
    }
  }
  const notes = d.breaking.map((b) => `BREAKING: ${b.reason} @ ${b.path}`);
  for (const change of d.changes) {
    if (change.path.startsWith("schema.fields.") && change.path.endsWith(".type")) {
      const note = `BREAKING: column type changed @ ${change.path}`;
      if (!notes.includes(note)) {
        notes.push(note);
      }
    }
  }
  return { steps, notes };
}
function generateSchema(manifest) {
  const fields = manifest.schema?.fields || {};
  const schema = {
    type: "object",
    properties: {},
    required: []
  };
  for (const [name, field] of Object.entries(fields)) {
    schema.properties[name] = {
      type: field.type,
      description: field.description
    };
    if (field.required) {
      schema.required.push(name);
    }
  }
  return JSON.stringify(schema, null, 2);
}
function generateValidation(manifest) {
  const fields = manifest.schema?.fields || {};
  const validations = [];
  for (const [name, field] of Object.entries(fields)) {
    if (field.required) {
      validations.push(`if (!data.${name}) throw new Error('${name} is required');`);
    }
    if (field.type === "string" && field.max_length) {
      validations.push(`if (data.${name} && data.${name}.length > ${field.max_length}) throw new Error('${name} exceeds max length');`);
    }
  }
  return `function validate(data) {
  ${validations.join("\n  ")}
  return true;
}`;
}
function generateDocs(manifest) {
  const name = manifest.dataset?.name || "Dataset";
  const fields = manifest.schema?.fields || {};
  let docs = `# ${name}

`;
  docs += `**Description**: ${manifest.dataset?.description || "No description"}

`;
  docs += `## Schema

`;
  docs += `| Field | Type | Required | Description |
`;
  docs += `|-------|------|----------|-------------|
`;
  for (const [name2, field] of Object.entries(fields)) {
    docs += `| ${name2} | ${field.type} | ${field.required ? "Yes" : "No"} | ${field.description || ""} |
`;
  }
  return docs;
}
function createDataProtocol(manifestInput = {}) {
  const manifest = normalize(manifestInput);
  return Object.freeze({
    manifest: () => clone(manifest),
    validate: (names = []) => runValidators(manifest, names),
    match: (expr) => query(manifest, expr),
    diff: (other) => diff(manifest, other),
    generateMigration: (other) => generateMigration(manifest, other),
    generateSchema: () => generateSchema(manifest),
    generateValidation: () => generateValidation(manifest),
    generateDocs: () => generateDocs(manifest),
    set: (path2, value) => {
      const m = clone(manifest);
      dset(m, path2, value);
      return createDataProtocol(m);
    }
  });
}

// src/proto.js
var createDataProtocol2 = createDataProtocol;
try {
  const dataProtocolModule = await import("@proto/data");
  if (dataProtocolModule?.createDataProtocol) {
    createDataProtocol2 = dataProtocolModule.createDataProtocol;
  }
} catch (error) {
  if (process?.env?.PROTO_DEBUG === "1") {
    console.warn("[proto-cli] fallback to local data protocol implementation:", error.message);
  }
}
function parseArgs(args) {
  const result = {
    command: null,
    subcommand: null,
    options: {},
    errors: []
  };
  if (args.length === 0) {
    result.errors.push("No command specified");
    return result;
  }
  result.command = args[0];
  let i = 1;
  if ((result.command === "generate" || result.command === "query" || result.command === "graph") && args.length > 1) {
    result.subcommand = args[1];
    i = 2;
  }
  while (i < args.length) {
    const arg = args[i];
    if (arg.startsWith("--")) {
      const [key, value] = arg.slice(2).split("=");
      if (value !== void 0) {
        result.options[key] = value;
      } else if (i + 1 < args.length && !args[i + 1].startsWith("--")) {
        result.options[key] = args[i + 1];
        i++;
      } else {
        result.options[key] = true;
      }
    } else {
      result.errors.push(`Unexpected argument: ${arg}`);
    }
    i++;
  }
  return result;
}
function loadManifest(filePath) {
  if (!filePath) {
    throw new Error("Manifest file path is required");
  }
  const fullPath = path.resolve(filePath);
  if (!fs.existsSync(fullPath)) {
    throw new Error(`Manifest file not found: ${filePath}`);
  }
  const content = fs.readFileSync(fullPath, "utf8");
  try {
    return JSON.parse(content);
  } catch (error) {
    throw new Error(`Invalid JSON in manifest file: ${error.message}`);
  }
}
function formatOutput(data, format = "text") {
  if (format === "json") {
    return JSON.stringify(data, null, 2);
  }
  if (typeof data === "string") {
    return data;
  }
  if (data && typeof data === "object") {
    if (data.valid !== void 0) {
      return formatValidationResult(data);
    }
    if (data.changes !== void 0) {
      return formatDiffResult(data);
    }
    if (data.steps !== void 0) {
      return formatMigrationResult(data);
    }
  }
  return JSON.stringify(data, null, 2);
}
function formatValidationResult(result) {
  const lines = [];
  const isValid = result.valid !== void 0 ? result.valid : result.ok;
  const validatorResults = result.validatorResults || result.results;
  if (isValid) {
    lines.push("\u2713 Manifest is valid");
  } else {
    lines.push("\u2717 Manifest validation failed");
  }
  if (result.errors && result.errors.length > 0) {
    lines.push("");
    lines.push("Errors:");
    result.errors.forEach((error) => {
      lines.push(`  - ${error}`);
    });
  }
  if (validatorResults) {
    lines.push("");
    lines.push("Validator Results:");
    validatorResults.forEach((validatorResult) => {
      const name = validatorResult.name || "unknown";
      const status = validatorResult.ok || validatorResult.valid ? "\u2713" : "\u2717";
      lines.push(`  ${status} ${name}`);
      if (validatorResult.issues && validatorResult.issues.length > 0) {
        validatorResult.issues.forEach((issue) => {
          const level = issue.level || "error";
          lines.push(`    - ${issue.path}: ${issue.msg} [${level}]`);
        });
      }
    });
  }
  return lines.join("\n");
}
function formatDiffResult(result) {
  const lines = [];
  if (result.changes && result.changes.length > 0) {
    lines.push(`Found ${result.changes.length} change(s):`);
    lines.push("");
    result.changes.forEach((change) => {
      const path2 = change.path || "unknown";
      const from = change.from !== void 0 ? JSON.stringify(change.from) : "(undefined)";
      const to = change.to !== void 0 ? JSON.stringify(change.to) : "(undefined)";
      lines.push(`  ${path2}:`);
      lines.push(`    from: ${from}`);
      lines.push(`    to:   ${to}`);
    });
  } else {
    lines.push("No changes detected");
  }
  if (result.breaking && result.breaking.length > 0) {
    lines.push("");
    lines.push(`\u26A0\uFE0F  ${result.breaking.length} breaking change(s):`);
    result.breaking.forEach((breaking) => {
      lines.push(`  - ${breaking.path}: ${breaking.reason}`);
    });
  }
  if (result.significant && result.significant.length > 0) {
    lines.push("");
    lines.push(`\u2139\uFE0F  ${result.significant.length} significant change(s):`);
    result.significant.forEach((sig) => {
      lines.push(`  - ${sig.path}`);
    });
  }
  return lines.join("\n");
}
function formatMigrationResult(result) {
  const lines = [];
  if (result.steps && result.steps.length > 0) {
    lines.push("Migration Steps:");
    lines.push("");
    result.steps.forEach((step, index) => {
      lines.push(`${index + 1}. ${step}`);
    });
  } else {
    lines.push("No migration steps required");
  }
  if (result.notes && result.notes.length > 0) {
    lines.push("");
    lines.push("Notes:");
    result.notes.forEach((note) => {
      lines.push(`  - ${note}`);
    });
  }
  return lines.join("\n");
}
function showHelp() {
  const help = `
Cross-Protocol Manifest System CLI

Usage:
  proto <command> [options]

Commands:
  validate              Validate a manifest file
  diff                  Compare two manifests
  generate migration    Generate migration script between manifests
  query                 Search manifests using query DSL
  graph                 Generate graph visualization of protocol relationships

Options:
  --manifest=<file>     Path to manifest file (JSON)
  --from=<file>         Source manifest file for diff/migration
  --to=<file>           Target manifest file for diff/migration
  --format=<format>     Output format: json, text, table (default: text)
  --help                Show this help message

Query Options:
  --manifest-dir=<path> Directory containing manifests (default: ./manifests)
  --type=<protocol>     Filter by protocol type (data, event, api, agent, semantic)
  --limit=N            Limit results (default: 10)

Graph Options:
  --format=mermaid|json|dot  Output format (default: mermaid)
  --depth=N           Traversal depth (default: 3)
  --show-dependencies Show inter-mission dependencies
  --show-urns         Show all URN references
  --output=<file>     Write to file instead of stdout

Examples:
  proto validate --manifest=dataset.json
  proto diff --from=v1.json --to=v2.json --format=json
  proto generate migration --from=v1.json --to=v2.json
  proto query 'governance.policy.classification:=:pii'
  proto query 'agent.capabilities.tools:contains:refund' --type=agent
  proto graph manifests/agent/support.json --format=mermaid
  proto graph manifests/data/users.json --show-dependencies --depth=2

Exit Codes:
  0 - Success
  1 - General error
  2 - Validation failed
  3 - File not found
  4 - Invalid manifest format
`;
  console.log(help);
}
async function handleValidate(parsed) {
  const { options } = parsed;
  if (!options.manifest) {
    console.error("Error: --manifest option is required");
    return 1;
  }
  try {
    const manifest = loadManifest(options.manifest);
    const protocol = createDataProtocol2(manifest);
    const protocolResult = await protocol.validate();
    const cliResult = {
      valid: protocolResult.ok,
      validatorResults: protocolResult.results,
      errors: []
    };
    if (protocolResult.results) {
      protocolResult.results.forEach((validatorResult) => {
        if (!validatorResult.ok && validatorResult.issues) {
          validatorResult.issues.forEach((issue) => {
            cliResult.errors.push(`${issue.path}: ${issue.msg}`);
          });
        }
      });
    }
    const output = formatOutput(cliResult, options.format || "text");
    console.log(output);
    return cliResult.valid ? 0 : 2;
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return error.message.includes("not found") ? 3 : 4;
  }
}
async function handleDiff(parsed) {
  const { options } = parsed;
  if (!options.from || !options.to) {
    console.error("Error: Both --from and --to options are required");
    return 1;
  }
  try {
    const manifestA = loadManifest(options.from);
    const manifestB = loadManifest(options.to);
    const protocolA = createDataProtocol2(manifestA);
    const result = protocolA.diff(manifestB);
    const output = formatOutput(result, options.format);
    console.log(output);
    return 0;
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return error.message.includes("not found") ? 3 : 4;
  }
}
async function handleGenerateMigration(parsed) {
  const { options } = parsed;
  if (!options.from || !options.to) {
    console.error("Error: Both --from and --to options are required");
    return 1;
  }
  try {
    const manifestA = loadManifest(options.from);
    const manifestB = loadManifest(options.to);
    const protocolA = createDataProtocol2(manifestA);
    const result = protocolA.generateMigration(manifestB);
    const output = formatOutput(result, options.format);
    console.log(output);
    return 0;
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return error.message.includes("not found") ? 3 : 4;
  }
}
function parseQueryExpression(expression) {
  const operators = [":=:", ":contains:", ">:", "<:", ">=:", "<=:", ":=array:"];
  for (const op of operators) {
    const parts = expression.split(op);
    if (parts.length === 2) {
      return {
        field: parts[0].trim(),
        operator: op,
        value: parts[1].trim().replace(/^["']|["']$/g, "")
      };
    }
  }
  throw new Error(`Invalid query expression: ${expression}. Supported operators: ${operators.join(", ")}`);
}
function getNestedValue(obj, path2) {
  return path2.split(".").reduce((current, key) => {
    return current && current[key] !== void 0 ? current[key] : void 0;
  }, obj);
}
function matchesQuery(actual, operator, expected) {
  if (actual === void 0) return false;
  if (Array.isArray(actual)) {
    if (operator === ":contains:") {
      return actual.some((item) => item.toString().toLowerCase().includes(expected.toLowerCase()));
    }
    if (operator === ":=array:") {
      const expectedArray = expected.split(",").map((v) => v.trim());
      return expectedArray.every((val) => actual.includes(val));
    }
    return false;
  }
  if (typeof actual === "string") {
    if (operator === ":contains:") {
      return actual.toLowerCase().includes(expected.toLowerCase());
    }
    if (operator === ":=:") {
      return actual.toLowerCase() === expected.toLowerCase();
    }
    return false;
  }
  const actualNum = Number(actual);
  const expectedNum = Number(expected);
  if (!isNaN(actualNum) && !isNaN(expectedNum)) {
    switch (operator) {
      case ">:":
        return actualNum > expectedNum;
      case "<:":
        return actualNum < expectedNum;
      case ">=:":
        return actualNum >= expectedNum;
      case "<=:":
        return actualNum <= expectedNum;
      case ":=:":
        return actualNum === expectedNum;
    }
  }
  if (operator === ":=:") {
    return actual == expected;
  }
  return false;
}
async function loadManifestsFromDir(dirPath, protocolType) {
  const fullPath = path.resolve(dirPath);
  if (!fs.existsSync(fullPath)) {
    throw new Error(`Manifest directory not found: ${dirPath}`);
  }
  const manifests = [];
  const files = fs.readdirSync(fullPath).filter((f) => f.endsWith(".json"));
  for (const file of files) {
    try {
      const filePath = path.join(fullPath, file);
      const content = fs.readFileSync(filePath, "utf8");
      const manifest = JSON.parse(content);
      if (!protocolType || manifest.type === protocolType) {
        manifests.push(manifest);
      }
    } catch (error) {
      console.error(`Warning: Skipping invalid manifest ${file}: ${error.message}`);
    }
  }
  return manifests;
}
function formatQueryResults(results) {
  if (results.length === 0) {
    return "No manifests found matching query";
  }
  const lines = [];
  lines.push(`Found ${results.length} manifest(s) matching query:`);
  lines.push("");
  results.forEach((result, index) => {
    lines.push(`${index + 1}. URN: ${result.urn || "unknown"}`);
    lines.push(`   Type: ${result.type || "unknown"}`);
    lines.push(`   Match: ${result.matchPath} ${result.operator} ${JSON.stringify(result.matchValue)}`);
    if (result.file) {
      lines.push(`   File: ${result.file}`);
    }
    lines.push("");
  });
  return lines.join("\n");
}
async function handleQuery(parsed) {
  const { options } = parsed;
  if (!parsed.subcommand) {
    console.error("Error: Query expression is required");
    return 1;
  }
  try {
    const query2 = parseQueryExpression(parsed.subcommand);
    const manifestDir = options["manifest-dir"] || "./manifests";
    const protocolType = options.type;
    const limit = parseInt(options.limit) || 10;
    const manifests = await loadManifestsFromDir(manifestDir, protocolType);
    const results = [];
    for (const manifest of manifests) {
      const value = getNestedValue(manifest, query2.field);
      if (matchesQuery(value, query2.operator, query2.value)) {
        results.push({
          urn: manifest.urn,
          type: manifest.type,
          matchPath: query2.field,
          operator: query2.operator,
          matchValue: value,
          manifest
        });
        if (results.length >= limit) break;
      }
    }
    const format = options.format || "table";
    let output;
    if (format === "json") {
      output = JSON.stringify(results, null, 2);
    } else if (format === "table") {
      output = formatQueryResults(results);
    } else {
      output = formatOutput(results, format);
    }
    console.log(output);
    return 0;
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return 1;
  }
}
function extractURNs(manifest) {
  const urns = /* @__PURE__ */ new Set();
  const jsonStr = JSON.stringify(manifest);
  const urnRegex = /urn:proto:[^"'\s]+/g;
  const matches = jsonStr.match(urnRegex);
  if (matches) {
    matches.forEach((urn) => urns.add(urn));
  }
  if (manifest.urn) {
    urns.delete(manifest.urn);
  }
  return Array.from(urns);
}
async function buildGraph(manifest, depth, visited = /* @__PURE__ */ new Set()) {
  const urn = manifest.urn || "unknown";
  if (visited.has(urn) || depth <= 0) {
    return null;
  }
  visited.add(urn);
  const node = {
    urn,
    type: manifest.type || "unknown",
    edges: []
  };
  const referencedURNs = extractURNs(manifest);
  for (const targetURN of referencedURNs) {
    node.edges.push({
      target: targetURN,
      relationship: "references"
    });
  }
  return node;
}
function generateMermaid(graph) {
  if (!graph) return "";
  const lines = ["graph TD"];
  const visited = /* @__PURE__ */ new Set();
  function processNode(node, parentId = null) {
    if (!node || visited.has(node.urn)) return;
    visited.add(node.urn);
    const nodeId = node.urn.replace(/[^a-zA-Z0-9]/g, "_");
    const label = `${node.type}:${node.urn.split(":").pop()}`;
    lines.push(`  ${nodeId}[${label}]`);
    if (parentId) {
      lines.push(`  ${parentId} -->|references| ${nodeId}`);
    }
    if (node.edges) {
      for (const edge of node.edges) {
        const targetId = edge.target.replace(/[^a-zA-Z0-9]/g, "_");
        lines.push(`  ${nodeId} -->|${edge.relationship}| ${targetId}[${edge.target}]`);
      }
    }
  }
  processNode(graph);
  return lines.join("\n");
}
function generateDot(graph) {
  if (!graph) return "";
  const lines = ["digraph G {", "  rankdir=TB;"];
  const visited = /* @__PURE__ */ new Set();
  function processNode(node, parentId = null) {
    if (!node || visited.has(node.urn)) return;
    visited.add(node.urn);
    const nodeId = node.urn.replace(/[^a-zA-Z0-9]/g, "_");
    const label = `${node.type}:${node.urn.split(":").pop()}`;
    lines.push(`  ${nodeId} [label="${label}"];`);
    if (parentId) {
      lines.push(`  ${parentId} -> ${nodeId} [label="references"];`);
    }
    if (node.edges) {
      for (const edge of node.edges) {
        const targetId = edge.target.replace(/[^a-zA-Z0-9]/g, "_");
        lines.push(`  ${nodeId} -> ${targetId} [label="${edge.relationship}"];`);
      }
    }
  }
  processNode(graph);
  lines.push("}");
  return lines.join("\n");
}
async function handleGraph(parsed) {
  const { options } = parsed;
  if (!parsed.subcommand) {
    console.error("Error: Manifest file path is required");
    return 1;
  }
  try {
    const manifestPath = parsed.subcommand;
    const manifest = loadManifest(manifestPath);
    const depth = parseInt(options.depth) || 3;
    const format = options.format || "mermaid";
    const graph = await buildGraph(manifest, depth);
    if (!graph) {
      console.log("No graph data available");
      return 0;
    }
    let output;
    switch (format) {
      case "mermaid":
        output = generateMermaid(graph);
        break;
      case "dot":
        output = generateDot(graph);
        break;
      case "json":
        output = JSON.stringify(graph, null, 2);
        break;
      default:
        throw new Error(`Unsupported format: ${format}`);
    }
    if (options.output) {
      fs.writeFileSync(options.output, output, "utf8");
      console.log(`Graph written to ${options.output}`);
    } else {
      console.log(output);
    }
    return 0;
  } catch (error) {
    console.error(`Error: ${error.message}`);
    return error.message.includes("not found") ? 3 : 4;
  }
}
async function main(args) {
  const startTime = Date.now();
  if (args.includes("--help") || args.includes("-h")) {
    showHelp();
    return 0;
  }
  const parsed = parseArgs(args);
  if (parsed.errors.length > 0) {
    parsed.errors.forEach((error) => console.error(`Error: ${error}`));
    showHelp();
    return 1;
  }
  let exitCode;
  switch (parsed.command) {
    case "validate":
      exitCode = await handleValidate(parsed);
      break;
    case "diff":
      exitCode = await handleDiff(parsed);
      break;
    case "generate":
      if (parsed.subcommand === "migration") {
        exitCode = await handleGenerateMigration(parsed);
      } else {
        console.error(`Error: Unknown generate subcommand: ${parsed.subcommand}`);
        showHelp();
        exitCode = 1;
      }
      break;
    case "query":
      exitCode = await handleQuery(parsed);
      break;
    case "graph":
      exitCode = await handleGraph(parsed);
      break;
    default:
      console.error(`Error: Unknown command: ${parsed.command}`);
      showHelp();
      exitCode = 1;
  }
  const duration = Date.now() - startTime;
  if (duration > 500) {
    console.error(`Warning: CLI execution took ${duration}ms (target: < 500ms)`);
  }
  return exitCode;
}
if (import.meta.url === `file://${process.argv[1]}`) {
  main(process.argv.slice(2)).then((exitCode) => process.exit(exitCode)).catch((error) => {
    console.error(`Fatal error: ${error.message}`);
    process.exit(1);
  });
}
export {
  formatOutput,
  loadManifest,
  main,
  parseArgs
};
//# sourceMappingURL=proto.js.map